﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace XRebirthCatUnpack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void UnpackButton_Click(object sender, EventArgs e)
        {
            string vCatFile     = CatFileTextBox.Text;
            int vIndex = vCatFile.IndexOf(".cat");
            if (0 > vIndex)
            {
                return;
            }
            string vCatDataFile = vCatFile.Remove(vIndex);
            vCatDataFile += ".dat";
            string vdest = DestFolderTextBox.Text;
            if (vdest[vdest.Length - 1] != '\\')
            {
                vdest += "\\";
            }
            int vMaxData = int.MaxValue >> 2;
            //char[] buffer = new char[vMaxData];
            Byte [] bytebuffer = new Byte[vMaxData];
            using (StreamReader vStreamDatReader = new StreamReader(vCatDataFile))
            {
                using (StreamReader vStreamReader = new StreamReader(vCatFile))
                {
                    while (!vStreamReader.EndOfStream)
                    {
                        string vOneLine = vStreamReader.ReadLine();
                        OutPutList.Items.Add(vOneLine);
                        vOneLine.Trim();
                        int vLastIndex = vOneLine.LastIndexOf(" ");
                        vOneLine = vOneLine.Remove(vLastIndex);
                        int vSecondLastIndex = vOneLine.LastIndexOf(" ");
                        vOneLine = vOneLine.Remove(vSecondLastIndex);
                        int vIndexSpace1 = vOneLine.LastIndexOf(" ");
                        string vTheFile = vOneLine.Remove(vIndexSpace1);
                        string vTheValue = vOneLine.Substring(vIndexSpace1 + 1);
                        Int64 vData = Convert.ToInt32(vTheValue);
                        DirectoryInfo vDirectroyInfo = new DirectoryInfo(vdest + vTheFile);
                        string vPath = Path.GetDirectoryName(vDirectroyInfo.FullName);
                        if (!Directory.Exists(vPath))
                        {
                            Directory.CreateDirectory(vPath);
                        }
                        string vTheFullFile = vDirectroyInfo.FullName;

                        do
                        {
                            int vBlockData = vMaxData;
                            vData = vData - (Int64)(vMaxData);
                            if (vData < 0)
                            {
                                vData = vData + (Int64)(vMaxData);
                                vBlockData = (int)(vData);
                                vData = 0;
                            }
                            vStreamDatReader.BaseStream.Read(bytebuffer, 0, vBlockData);                           
                            //vStreamDatReader.ReadBlock(buffer, 0, vBlockData);
                            using (StreamWriter vStreamWriter = new StreamWriter(vTheFullFile))
                            {
                                vStreamWriter.BaseStream.Write(bytebuffer, 0, vBlockData);
                            }
                        } while (0 < vData);
                    }
                }
            }
            OutPutList.Items.Add("finish");
        }
    }
}
