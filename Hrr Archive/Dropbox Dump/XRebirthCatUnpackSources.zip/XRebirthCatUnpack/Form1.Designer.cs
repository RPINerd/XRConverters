﻿namespace XRebirthCatUnpack
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.CatFileTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DestFolderTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.UnpackButton = new System.Windows.Forms.Button();
            this.OutPutList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // CatFileTextBox
            // 
            this.CatFileTextBox.Location = new System.Drawing.Point(108, 25);
            this.CatFileTextBox.Name = "CatFileTextBox";
            this.CatFileTextBox.Size = new System.Drawing.Size(571, 22);
            this.CatFileTextBox.TabIndex = 0;
            this.CatFileTextBox.Text = "D:\\Steam\\steamapps\\common\\X Rebirth\\07.cat";
            this.CatFileTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "CatFile";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // DestFolderTextBox
            // 
            this.DestFolderTextBox.Location = new System.Drawing.Point(108, 66);
            this.DestFolderTextBox.Name = "DestFolderTextBox";
            this.DestFolderTextBox.Size = new System.Drawing.Size(571, 22);
            this.DestFolderTextBox.TabIndex = 2;
            this.DestFolderTextBox.Text = "D:\\XRCatUnpack";
            this.DestFolderTextBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Dest";
            // 
            // UnpackButton
            // 
            this.UnpackButton.Location = new System.Drawing.Point(217, 114);
            this.UnpackButton.Name = "UnpackButton";
            this.UnpackButton.Size = new System.Drawing.Size(276, 47);
            this.UnpackButton.TabIndex = 4;
            this.UnpackButton.Text = "Unpack";
            this.UnpackButton.UseVisualStyleBackColor = true;
            this.UnpackButton.Click += new System.EventHandler(this.UnpackButton_Click);
            // 
            // OutPutList
            // 
            this.OutPutList.FormattingEnabled = true;
            this.OutPutList.ItemHeight = 16;
            this.OutPutList.Location = new System.Drawing.Point(75, 210);
            this.OutPutList.Name = "OutPutList";
            this.OutPutList.Size = new System.Drawing.Size(590, 84);
            this.OutPutList.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 329);
            this.Controls.Add(this.OutPutList);
            this.Controls.Add(this.UnpackButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DestFolderTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CatFileTextBox);
            this.Name = "Form1";
            this.Text = "XRebirthCatUnpack";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox CatFileTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DestFolderTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button UnpackButton;
        private System.Windows.Forms.ListBox OutPutList;
    }
}

