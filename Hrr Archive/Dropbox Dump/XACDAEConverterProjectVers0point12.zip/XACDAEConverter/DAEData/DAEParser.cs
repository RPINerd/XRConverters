﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAENamespace;
using grendgine_collada;

namespace DAENamespace
{

    public class DAEParser
    {

        DAEData mDAEData;
        TextBox mStatusTextBox;
        ListBox mListBox;
        string mFileName;

        public DAEParser(string iFileName, DAEData xDAEData, TextBox iStatusTextBox, ListBox iListBox1)
        {
            mDAEData = xDAEData;
            mStatusTextBox = iStatusTextBox;
            mListBox = iListBox1;
            mFileName = iFileName;
        }

        public bool Parse()
        {
            bool vError = false;

            mListBox.Items.Clear();
            mStatusTextBox.Text = string.Empty;
            mDAEData.mDAEModelData = Grendgine_Collada.Grendgine_Load_File(mFileName);

            if (null == mDAEData.mDAEModelData)
            {
                //XML readin from Collada failed
                vError = true;
            }

            if (!vError)
            {
                Trace("Finish. DAE Imported");
                mStatusTextBox.Text = "Finish. DAE Imported";
            }
            else
            {
                Trace("Error. DAE Data Extraction failed.");
                mStatusTextBox.Text = "Error. DAE Data Extraction failed.";
                mDAEData.Clear();
            }

            return !vError;
        }

        private void Trace(string iString)
        {
            Console.WriteLine(iString);
            mListBox.Items.Add(iString);
            mListBox.SetSelected(mListBox.Items.Count - 1, true);
        }
    }

}
