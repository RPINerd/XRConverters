﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using grendgine_collada;

namespace DAENamespace
{
    public class DAEData
    {
        public Grendgine_Collada mDAEModelData;

        public DAEData()
        {
            mDAEModelData = new Grendgine_Collada();
        }

        public void Clear()
        {
            mDAEModelData = new Grendgine_Collada();
        }
    }

}