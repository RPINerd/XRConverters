﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using XACNamespace;
using DAENamespace;

namespace XACDAEConverter
{
  // XAC DAE Converter project started by TargetLost meant for xrebirth modding. (check steam and egosoft forums)
  //
  // For the XAC structre this phyton script noesis plugin was the template: fmt_DKOnline_xac.py
  //
  // The Collada C# Classes are from that project:
  // http://sourceforge.net/projects/csharpcollada/
  // v0.12 continued arc_'s File spec integration, added NodeTree and Node classes
  // v0.11 continued arc_'s File spec integration, added XACMath classes and adapted XACBone
  // v0.10 continued arc_'s File spec integration, transform classes to self reading and writing classes
  // v0.09 continued arc_'s File spec integration, transform classes to self reading and writing classes
  // v0.08 start of arc_'s File spec integration
  // v0.07 ChunkID2 parser attempt. Good start but then Failed due to a struct in struct and wrong entry counts
  // v0.06 ChunkID2,ID11,ID2 read into a buffer added for analysis
  // v0.05 added MaterialChunckID5 parsing, TetxtureParsing and SubChunk parsing (ChunkID13)
  // v0.04 Moved XAC Model classes into own files 
  // v0.03 added ToString() methods for better data anlysis when debugging.
  // v0.02 mixup between Face and VerticesIndex cleared up. XAC seems to work with triangles only. 
  // v0.01 start

  public partial class XACDAEForm : Form
  {

    private const string sVerison = "v0.12";

    private XACDAEPackage      mXACDAEPackage;
    private OpenFileDialog     mOpenFileDialog;

    public XACDAEForm()
    {
      InitializeComponent();
      InitData();
    }

    private void InitData()
    {
      //Title
      Text = "XAC DAE Converter" + " " + sVerison;

      //Data
      mXACDAEPackage = new XACDAEPackage();

      //File Open Dialog
      mOpenFileDialog = new OpenFileDialog();
      //mOpenFileDialog.InitialDirectory = "";
      //mOpenFileDialog.InitialDirectory = Application.StartupPath;
      //mOpenFileDialog.InitialDirectory = "D:\\CSharp\\XACDAEConverter\\Test";
      //mOpenFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
      mOpenFileDialog.Filter = "All files (*.*)|*.*";
      mOpenFileDialog.FilterIndex = 1;
      mOpenFileDialog.RestoreDirectory = true;
    }


    private void XACtoDAEButton_Click(object sender, EventArgs e)
    {
       mOpenFileDialog.Filter = "xac files (*.xac)|*.xac|All files (*.*)|*.*";

      Stream vStream = null;
      if (mOpenFileDialog.ShowDialog() == DialogResult.OK)
      {
        mOpenFileDialog.InitialDirectory = mOpenFileDialog.FileName;
        try
        {
          if ((vStream = mOpenFileDialog.OpenFile()) != null)
          {
            using (vStream)
            {
              Console.WriteLine("Parse XAC File");
              StatusTextBox.Text = "Parse XAC File";
              BinaryReader vBinarySteamReader = new BinaryReader(vStream);

              mXACDAEPackage  = new XACDAEPackage();
              XACParser vXACParser = new XACParser(vBinarySteamReader, mXACDAEPackage.mXACData, StatusTextBox, ListBox1);
              vXACParser.Parse();

            }
          }
        }
        catch (Exception vException)
        {
          Console.WriteLine(vException.ToString());
          StatusTextBox.Text =  vException.ToString();
        }
      }
    }


    private void DAEtoXACButton_Click(object sender, EventArgs e)
    {
        mOpenFileDialog.Filter = "dae files (*.dae)|*.dae|All files (*.*)|*.*";

        if (mOpenFileDialog.ShowDialog() == DialogResult.OK)
        {
            mOpenFileDialog.InitialDirectory = mOpenFileDialog.FileName;
            try
            {

                Console.WriteLine("Parse DAE File");
                StatusTextBox.Text = "Parse DAE File";

                mXACDAEPackage = new XACDAEPackage();
                DAEParser vDAEParser = new DAEParser(mOpenFileDialog.FileName, mXACDAEPackage.mDAEData, StatusTextBox, ListBox1);
                vDAEParser.Parse();

            }
            catch (Exception vException)
            {
                Console.WriteLine(vException.ToString());
                StatusTextBox.Text = vException.ToString();
            }
        }
    }

  }
}
