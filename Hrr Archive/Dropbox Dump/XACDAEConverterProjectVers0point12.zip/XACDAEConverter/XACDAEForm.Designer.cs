﻿namespace XACDAEConverter
{
  partial class XACDAEForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.XACToDAEButton = new System.Windows.Forms.Button();
            this.DAEtoXACButton = new System.Windows.Forms.Button();
            this.StatusTextBox = new System.Windows.Forms.TextBox();
            this.ListBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // XACToDAEButton
            // 
            this.XACToDAEButton.Location = new System.Drawing.Point(115, 30);
            this.XACToDAEButton.Margin = new System.Windows.Forms.Padding(4);
            this.XACToDAEButton.Name = "XACToDAEButton";
            this.XACToDAEButton.Size = new System.Drawing.Size(157, 42);
            this.XACToDAEButton.TabIndex = 0;
            this.XACToDAEButton.Text = "XAC -> DAE";
            this.XACToDAEButton.UseVisualStyleBackColor = true;
            this.XACToDAEButton.Click += new System.EventHandler(this.XACtoDAEButton_Click);
            // 
            // DAEtoXACButton
            // 
            this.DAEtoXACButton.Location = new System.Drawing.Point(325, 30);
            this.DAEtoXACButton.Margin = new System.Windows.Forms.Padding(4);
            this.DAEtoXACButton.Name = "DAEtoXACButton";
            this.DAEtoXACButton.Size = new System.Drawing.Size(157, 41);
            this.DAEtoXACButton.TabIndex = 1;
            this.DAEtoXACButton.Text = "DAE -> XAC";
            this.DAEtoXACButton.UseVisualStyleBackColor = true;
            this.DAEtoXACButton.Click += new System.EventHandler(this.DAEtoXACButton_Click);
            // 
            // StatusTextBox
            // 
            this.StatusTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusTextBox.Location = new System.Drawing.Point(38, 386);
            this.StatusTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.StatusTextBox.Name = "StatusTextBox";
            this.StatusTextBox.Size = new System.Drawing.Size(544, 30);
            this.StatusTextBox.TabIndex = 2;
            // 
            // ListBox1
            // 
            this.ListBox1.FormattingEnabled = true;
            this.ListBox1.ItemHeight = 16;
            this.ListBox1.Location = new System.Drawing.Point(38, 90);
            this.ListBox1.Name = "ListBox1";
            this.ListBox1.Size = new System.Drawing.Size(544, 276);
            this.ListBox1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(463, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "This Tool is In Development. NO OUTPUT FILES WILL BE GENERATED";
            // 
            // XACDAEForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 429);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ListBox1);
            this.Controls.Add(this.StatusTextBox);
            this.Controls.Add(this.DAEtoXACButton);
            this.Controls.Add(this.XACToDAEButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "XACDAEForm";
            this.Text = "XAC DAE Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button XACToDAEButton;
    private System.Windows.Forms.Button DAEtoXACButton;
    private System.Windows.Forms.TextBox StatusTextBox;
    private System.Windows.Forms.ListBox ListBox1;
    private System.Windows.Forms.Label label1;
  }
}

