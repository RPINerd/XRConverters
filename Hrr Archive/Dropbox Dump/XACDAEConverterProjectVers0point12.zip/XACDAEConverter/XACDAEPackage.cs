﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XACNamespace;
using DAENamespace;

namespace XACDAEConverter
{

  public class XACDAEPackage
  {
    public XACData   mXACData;
    public DAEData   mDAEData;

    public XACDAEPackage()
    {
      mXACData = new XACData();
      mDAEData = new DAEData();
    }
  }

}
