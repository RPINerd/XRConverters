﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XACNamespace
{
    public class XACMaterial
    {
        public string mName;
        public List<XACMatTextureEntry> mMatTextureEntryList;

        public XACMaterial(string iName, List<XACMatTextureEntry> iMatTextureEntryList)
        {
            mName = string.Empty;
            if (!string.IsNullOrEmpty(iName))
            {
                mName = iName;
            }
            mMatTextureEntryList = new List<XACMatTextureEntry>(iMatTextureEntryList);
        }

        public override string ToString()
        {
            int vMatTextureEntryCount = 0;
            if (null != mMatTextureEntryList)
            {
                vMatTextureEntryCount = mMatTextureEntryList.Count;
            }
            string vName = string.Empty;
            if (!string.IsNullOrEmpty(mName))
            {
                vName = mName;
            }
            string vTheString = "XACMaterial Name: " + vName + " Entries:" + vMatTextureEntryCount.ToString();
            return vTheString;
        }
    }

}
