﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{

    public class XACMaterialTotals
    {
        //(v1)

       UInt32 mTotalMaterialsCount;
       UInt32 mStandardMaterialsCount;
       UInt32 mFxMaterialsCount;


       public XACMaterialTotals()
       {
           mTotalMaterialsCount = 0;
           mStandardMaterialsCount = 0;
           mFxMaterialsCount = 0;
       }

        public void ReadIn(BinaryReader iStream)
        {
            mTotalMaterialsCount    = iStream.ReadUInt32();
            mStandardMaterialsCount = iStream.ReadUInt32();
            mFxMaterialsCount       = iStream.ReadUInt32();
        }


        public void WriteOut(BinaryWriter iStream)
        {
            iStream.Write(mTotalMaterialsCount);
            iStream.Write(mStandardMaterialsCount);
            iStream.Write(mFxMaterialsCount);
        }


        public long GetSize()
        {
            long vSize = 0;
            vSize += (long)sizeof(UInt32);
            vSize += (long)sizeof(UInt32);
            vSize += (long)sizeof(UInt32);
            return vSize;
        }


        public override string ToString()
        {
            string vTheString = "TotalMaterialsCount: " + mTotalMaterialsCount.ToString() + "  StandardMaterialsCount: " + mStandardMaterialsCount.ToString() + "  FxMaterialsCount: " + mFxMaterialsCount.ToString();
            return vTheString;
        }

    }

}
