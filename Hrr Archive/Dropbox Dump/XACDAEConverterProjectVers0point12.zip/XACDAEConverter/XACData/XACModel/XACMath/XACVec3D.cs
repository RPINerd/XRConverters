﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{
  public class XACVec3D
  {
    public float mX;
    public float mY;
    public float mZ;

    public XACVec3D()
    {
      mX = 0.0f;
      mY = 0.0f;
      mZ = 0.0f;
    }

    public void ReadIn(BinaryReader iStream)
    {
      mX = iStream.ReadSingle();
      mY = iStream.ReadSingle();
      mZ = iStream.ReadSingle();
    }


    public void WriteOut(BinaryWriter iStream)
    {
      iStream.Write(mX);
      iStream.Write(mY);
      iStream.Write(mZ);
    }


    public long GetSize()
    {
      long vSize = 0;
      vSize += (long)sizeof(float);
      vSize += (long)sizeof(float);
      vSize += (long)sizeof(float);
      return vSize;
    }


    public override string ToString()
    {
      string vTheString = "XACVec3D X: " + mX.ToString() + "  Y: " + mY.ToString() + "  Z: " + mZ.ToString();
      return vTheString;
    }

  }
}
