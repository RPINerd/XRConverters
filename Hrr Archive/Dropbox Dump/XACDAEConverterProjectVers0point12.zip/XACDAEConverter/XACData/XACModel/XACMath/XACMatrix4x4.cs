﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{
  public class XACMatrix4x4
  {
    public XACVec4D mCol1;
    public XACVec4D mCol2;
    public XACVec4D mCol3;
    public XACVec4D mPos;

    public XACMatrix4x4()
    {
      mCol1 = new XACVec4D(1.0f, 0.0f, 0.0f, 0.0f);
      mCol2 = new XACVec4D(0.0f, 1.0f, 0.0f, 0.0f);
      mCol3 = new XACVec4D(0.0f, 0.0f, 1.0f, 0.0f);
      mPos  = new XACVec4D(0.0f, 0.0f, 0.0f, 1.0f);
    }

    public void ReadIn(BinaryReader iStream)
    {
      mCol1.ReadIn(iStream);
      mCol2.ReadIn(iStream);
      mCol3.ReadIn(iStream);
      mPos.ReadIn(iStream);
    }


    public void WriteOut(BinaryWriter iStream)
    {
      mCol1.WriteOut(iStream);
      mCol2.WriteOut(iStream);
      mCol3.WriteOut(iStream);
      mPos.WriteOut(iStream);
    }


    public long GetSize()
    {
      long vSize = 0;
      vSize += mCol1.GetSize();
      vSize += mCol2.GetSize();
      vSize += mCol3.GetSize();
      vSize += mPos.GetSize();
      return vSize;
    }


    public override string ToString()
    {
      string vTheString = "XACMatrix4x4 Col1: " + mCol1.ToString() + "  Col2: " + mCol2.ToString() + "  Col3: " + mCol3.ToString() + "  Pos: " + mPos.ToString();
      return vTheString;
    }

  }
}
