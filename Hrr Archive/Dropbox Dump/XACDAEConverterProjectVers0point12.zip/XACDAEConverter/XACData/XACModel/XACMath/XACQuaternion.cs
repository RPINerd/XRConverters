﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{
  public class XACQuaternion
  {
    public float mQx;
    public float mQy;
    public float mQz;
    public float mQw;

    public XACQuaternion()
    {
      mQx = 0.0f;
      mQy = 0.0f;
      mQz = 0.0f;
      mQw = 1.0f;
    }

    public void ReadIn(BinaryReader iStream)
    {
      mQx = iStream.ReadSingle();
      mQy = iStream.ReadSingle();
      mQz = iStream.ReadSingle();
      mQw = iStream.ReadSingle();
    }


    public void WriteOut(BinaryWriter iStream)
    {
      iStream.Write(mQx);
      iStream.Write(mQy);
      iStream.Write(mQz);
      iStream.Write(mQw);
    }


    public long GetSize()
    {
      long vSize = 0;
      vSize += (long)sizeof(float);
      vSize += (long)sizeof(float);
      vSize += (long)sizeof(float);
      vSize += (long)sizeof(float);
      return vSize;
    }


    public override string ToString()
    {
      string vTheString = "XACQuaternion Qx: " + mQx.ToString() + "  Qy: " + mQy.ToString() + "  Qz: " + mQz.ToString() + "  Qw: " + mQw.ToString();
      return vTheString;
    }

  }
}
