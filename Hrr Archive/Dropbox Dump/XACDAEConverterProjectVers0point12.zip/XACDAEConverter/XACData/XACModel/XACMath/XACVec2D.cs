﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{
  public class XACVec2D
  {
    public float mX;
    public float mY;

    public XACVec2D()
    {
      mX = 0.0f;
      mY = 0.0f;
    }

    public void ReadIn(BinaryReader iStream)
    {
      mX = iStream.ReadSingle();
      mY = iStream.ReadSingle();
    }


    public void WriteOut(BinaryWriter iStream)
    {
      iStream.Write(mX);
      iStream.Write(mY);
    }


    public long GetSize()
    {
      long vSize = 0;
      vSize += (long)sizeof(float);
      vSize += (long)sizeof(float);
      return vSize;
    }


    public override string ToString()
    {
      string vTheString = "XACVec2D X: " + mX.ToString() + "  Y: " + mY.ToString();
      return vTheString;
    }

  }
}
