﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{

    public class XACMetaData
    {
        //(v2)

        //constants for the Reposition Mask
        public const UInt32 cRepositionPos   = 1;
        public const UInt32 cRepositionRot   = 2;
        public const UInt32 cRepositionScale = 4;
       
        public UInt32 mRepositionMask;
        public Int32  mRepositioningNode;
        public Byte   mExporterMajorVersion;
        public Byte   mExporterMinorVersion;
        public Byte   mNotKnownUnused1;
        public Byte   mNotKnownUnused2;
        public float  mRetargetRootOffset; 

        public string mCreatorProgram;
        public string mModelFileName;
        public string mCreationDate;
        public string mActorName;

        public XACMetaData()
        {
    
          mRepositionMask       = cRepositionPos;
          mRepositioningNode    = -1;
          mExporterMajorVersion = 1;
          mExporterMinorVersion = 0;
          mNotKnownUnused1      = 0;
          mNotKnownUnused2      = 0;
          mRetargetRootOffset   = 0.0f;

          mCreatorProgram = string.Empty;
          mModelFileName  = string.Empty;
          mCreationDate   = string.Empty;
          mActorName      = string.Empty;
        }

        public void ReadIn(BinaryReader iStream)
        {
          mRepositionMask       = iStream.ReadUInt32(); //01 00 00 00
          mRepositioningNode    = iStream.ReadInt32();  //255 255 255 255
          mExporterMajorVersion = iStream.ReadByte();   //3
          mExporterMinorVersion = iStream.ReadByte();   //132
          mNotKnownUnused1      = iStream.ReadByte();   //26
          mNotKnownUnused2      = iStream.ReadByte();   //106
          mRetargetRootOffset   = iStream.ReadSingle();//0 0 0 0

          mCreatorProgram = Common.ReadString(iStream); //45 0 0 0 . 51
          mModelFileName  = Common.ReadString(iStream); //69 0 0 0 . 70
          mCreationDate   = Common.ReadString(iStream); //11 0 0 0 . 65
          mActorName      = Common.ReadString(iStream); //0 0 0 0
        }


        public void WriteOut(BinaryWriter iStream)
        {
          iStream.Write(mRepositionMask);
          iStream.Write(mRepositioningNode);
          iStream.Write(mExporterMajorVersion);
          iStream.Write(mExporterMinorVersion);
          iStream.Write(mNotKnownUnused1);
          iStream.Write(mNotKnownUnused2);
          iStream.Write(mRetargetRootOffset);

          Common.WriteString(iStream, mCreatorProgram);
          Common.WriteString(iStream, mModelFileName);
          Common.WriteString(iStream, mCreationDate);
          Common.WriteString(iStream, mActorName);
        }

        public long GetSize()
        {
            //That should sum up to 8  Bytes...usually
            long vSize = 0;
            vSize += (long)sizeof(UInt32);
            vSize += (long)sizeof(Int32);
            vSize += (long)sizeof(Byte);
            vSize += (long)sizeof(Byte);
            vSize += (long)sizeof(Byte);
            vSize += (long)sizeof(Byte);
            vSize += (long)sizeof(float);

            vSize += (long)(mCreatorProgram.Length);
            vSize += (long)(mModelFileName.Length);
            vSize += (long)(mCreationDate.Length);
            vSize += (long)(mActorName.Length);
            return vSize;
        }


        public override string ToString()
        {
            string vTheString = "CreatorProgram: " + mCreatorProgram + "  ModelFileName: " + mModelFileName + "  CreationDate: " + mCreationDate + "  ActorName: " + mActorName;
          return vTheString;
        }

    }

}
