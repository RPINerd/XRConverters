﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{

    public class XACBone
    {
        XACQuaternion mRotation;
        float  mUnkIdx4;
        float  mUnkIdx5;
        float  mUnkIdx6;
        float  mUnkIdx7;
        XACVec3D mLocation;
        float  mUnkIdx11;
        float  mUnkIdx12;
        float  mUnkIdx13;
        float  mUnkIdx14;
        float  mUnkIdx15;
        int    mUnkIdx16;
        int    mUnkIdx17;
        int    mParentID;
        int    mUnkIdx19;
        string mBoneName;

        public XACBone()
        {
          mRotation = new XACQuaternion();
          mUnkIdx4 = 0.0f;
          mUnkIdx5 = 0.0f;
          mUnkIdx6 = 0.0f;
          mUnkIdx7 = 0.0f;
          mLocation = new XACVec3D();
          mUnkIdx11 = 0.0f;
          mUnkIdx12 = 0.0f;
          mUnkIdx13 = 0.0f;
          mUnkIdx14 = 0.0f;
          mUnkIdx15 = 0.0f;
          mUnkIdx16 = 0;
          mUnkIdx17 = 0;
          mParentID = 0;
          mUnkIdx19 = 0;
          mBoneName = string.Empty;
        }


        public void ReadIn(BinaryReader iStream)
        {
          mRotation.ReadIn(iStream);
          mUnkIdx4 = iStream.ReadSingle();
          mUnkIdx5 = iStream.ReadSingle();
          mUnkIdx6 = iStream.ReadSingle();
          mUnkIdx7 = iStream.ReadSingle();
          mLocation.ReadIn(iStream);
          mUnkIdx11 = iStream.ReadSingle();
          mUnkIdx12 = iStream.ReadSingle();
          mUnkIdx13 = iStream.ReadSingle();
          mUnkIdx14 = iStream.ReadSingle();
          mUnkIdx15 = iStream.ReadSingle();
          mUnkIdx16 = iStream.ReadInt32();
          mUnkIdx17 = iStream.ReadInt32();
          mParentID = iStream.ReadInt32();
          mUnkIdx19 = iStream.ReadInt32();
          mBoneName = Common.ReadString(iStream);
        }


        public void WriteOut(BinaryWriter iStream)
        {
          mRotation.WriteOut(iStream);
          iStream.Write(mUnkIdx4);
          iStream.Write(mUnkIdx5);
          iStream.Write(mUnkIdx6);
          iStream.Write(mUnkIdx7);
          mLocation.WriteOut(iStream);
          iStream.Write(mUnkIdx11);
          iStream.Write(mUnkIdx12);
          iStream.Write(mUnkIdx13);
          iStream.Write(mUnkIdx14);
          iStream.Write(mUnkIdx15);
          iStream.Write(mUnkIdx16);
          iStream.Write(mUnkIdx17);
          iStream.Write(mParentID);
          iStream.Write(mUnkIdx19);
          Common.WriteString(iStream, mBoneName);
        }

        public long GetSize()
        {
          long vSize = 0;
          vSize += mRotation.GetSize();
          vSize += 4L * (long)sizeof(float);
          vSize += mLocation.GetSize();
          vSize += 5L * (long)sizeof(float);
          vSize += (long)sizeof(int);
          vSize += (long)sizeof(int);
          vSize += (long)sizeof(int);
          vSize += (long)sizeof(int);
          vSize += (long)(mBoneName.Length);
          return vSize;
        }

        public override string ToString()
        {
            string vBoneName = string.Empty;
            if (!string.IsNullOrEmpty(vBoneName))
            {
                vBoneName = mBoneName;
            }
            string vTheString = "XACBone Name: " + vBoneName.ToString() +
                                "  Rotation: " + mRotation.ToString() +
                                "  Location: " + mLocation.ToString() +
                                "  ParentID: " + mParentID.ToString();
            return vTheString;
        }

    }


}