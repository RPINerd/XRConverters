﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XACNamespace
{

    public class XACModelData
    {
        public XACMetaData mMetaData;
        public XACNodeTree mNodeTree;
        public List<XACMesh> mMeshesList;
        public List<XACAnimation> mAnimationList;
        public List<XACTexture> mTextureList;
        public List<XACUnknownOfChunkID2> mUnknownOfChunkID2List;
        public XACMaterialTotals mMaterialTotals;
        public List<XACMaterial> mMaterialListChunkID3;
        public List<XACMaterial> mMaterialListChunkID5;
        public List<XACBone> mBonesList;

        public XACModelData()
        {
            mMetaData = new XACMetaData();
            mNodeTree = new XACNodeTree();
            mMeshesList = new List<XACMesh>();
            mAnimationList = new List<XACAnimation>();
            mTextureList = new List<XACTexture>();
            mUnknownOfChunkID2List = new List<XACUnknownOfChunkID2>();
            mMaterialTotals = new XACMaterialTotals();
            mMaterialListChunkID3 = new List<XACMaterial>();
            mMaterialListChunkID5 = new List<XACMaterial>();
            mBonesList = new List<XACBone>();
        }
    }

}