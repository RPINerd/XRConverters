﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{

    public class XACNodeTree
    {
        UInt32 mNodesCount;
        UInt32 mRootNodesCount; //(number of nodes with parentId = -1)
        List<XACNode> mNodeList;

        public XACNodeTree()
        {
          mNodesCount = 0;
          mRootNodesCount = 0;
          mNodeList = new List<XACNode>();
        }


        public void ReadIn(BinaryReader iStream)
        {
            mNodesCount = iStream.ReadUInt32();
            mRootNodesCount = iStream.ReadUInt32();
            mNodeList.Clear();
            for (int vEntryNr = 1; vEntryNr <= mNodesCount; vEntryNr++)
            {
                XACNode vXACNode = new XACNode();
                vXACNode.ReadIn(iStream);
                mNodeList.Add(vXACNode);
            }
        }


        public void WriteOut(BinaryWriter iStream)
        {
            iStream.Write(mNodesCount);
            iStream.Write(mRootNodesCount);
            foreach (XACNode vXACNode in mNodeList)
            {
                vXACNode.WriteOut(iStream);
            }
        }

        public long GetSize()
        {
            long vSize = 0;
            vSize += (long)sizeof(UInt32);
            vSize += (long)sizeof(UInt32);
            foreach (XACNode vXACNode in mNodeList)
            {
                vSize += vXACNode.GetSize();
            }
            return vSize;
        }

        public override string ToString()
        {
            string vTheString = "XACNodeTree NodesCount: " + mNodesCount.ToString() +
                                "  RotationRootNodesCount: " + mRootNodesCount.ToString();
            return vTheString;
        }

    }


}