﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{

    public class XACNode
    {
        XACQuaternion mRotation;
        XACQuaternion mScaleRotation;
        XACVec3D mLocation;
        XACVec3D mScale;
        float mUnk1; //-1.0f
        float mUnk2; //-1.0f
        float mUnk3; //-1.0f
        Int32 mUnk4; //-1
        Int32 mUnk5; //-1
        Int32 mParentNodeId; //(index of parent node or -1 for root nodes)
        Int32 mChildNodesCount; //(number of nodes with parentId = this node's index)
        Int32 mIncludeInBoundsCalcFlag;
        XACMatrix4x4 mTransformation;
        float mImportanceFactor;
        String mName;

        public XACNode()
        {
            mRotation = new XACQuaternion();
            mScaleRotation = new XACQuaternion();
            mLocation = new XACVec3D();
            mScale = new XACVec3D();
            mUnk1 = -1.0f;
            mUnk2 = -1.0f;
            mUnk3 = -1.0f;
            mUnk4 = -1;
            mUnk5 = -1;
            mParentNodeId = -1;
            mChildNodesCount = 0;
            mIncludeInBoundsCalcFlag = 0;
            mTransformation = new XACMatrix4x4();
            mImportanceFactor = 0.0f;
            mName = string.Empty;
        }


        public void ReadIn(BinaryReader iStream)
        {
            mRotation.ReadIn(iStream);
            mScaleRotation.ReadIn(iStream);
            mLocation.ReadIn(iStream);
            mScale.ReadIn(iStream);
            mUnk1 = iStream.ReadSingle();
            mUnk2 = iStream.ReadSingle();
            mUnk3 = iStream.ReadSingle();
            mUnk4 = iStream.ReadInt32();
            mUnk5 = iStream.ReadInt32();
            mParentNodeId = iStream.ReadInt32();
            mChildNodesCount = iStream.ReadInt32();
            mIncludeInBoundsCalcFlag = iStream.ReadInt32();
            mTransformation.ReadIn(iStream);
            mImportanceFactor = iStream.ReadSingle();
            mName = Common.ReadString(iStream);
        }


        public void WriteOut(BinaryWriter iStream)
        {
            mRotation.WriteOut(iStream);
            mScaleRotation.WriteOut(iStream);
            mLocation.WriteOut(iStream);
            mScale.WriteOut(iStream);
            iStream.Write(mUnk1);
            iStream.Write(mUnk2);
            iStream.Write(mUnk3);
            iStream.Write(mUnk4);
            iStream.Write(mUnk5);
            iStream.Write(mParentNodeId);
            iStream.Write(mChildNodesCount);
            iStream.Write(mIncludeInBoundsCalcFlag);
            mTransformation.WriteOut(iStream);
            iStream.Write(mImportanceFactor);
            Common.WriteString(iStream, mName);
        }

        public long GetSize()
        {
            long vSize = 0;
            vSize += mRotation.GetSize();
            vSize += mScaleRotation.GetSize();
            vSize += mLocation.GetSize();
            vSize += mScale.GetSize();
            vSize += (long)sizeof(float);
            vSize += (long)sizeof(float);
            vSize += (long)sizeof(float);
            vSize += (long)sizeof(Int32);
            vSize += (long)sizeof(Int32);
            vSize += (long)sizeof(Int32);
            vSize += (long)sizeof(Int32);
            vSize += (long)sizeof(Int32);
            vSize += mTransformation.GetSize();
            vSize += (long)sizeof(float);
            vSize += (long)(mName.Length);
            return vSize;
        }

        public override string ToString()
        {
            string vName = string.Empty;
            if (!string.IsNullOrEmpty(vName))
            {
                vName = mName;
            }
            string vTheString = "XACNode Name: " + vName.ToString() +
                                "  ParentNodeId: " + mParentNodeId.ToString() +
                                "  ChildNodesCount: " + mChildNodesCount.ToString() +
                                "  Rotation: " + mRotation.ToString() +
                                "  ScaleRotation: " + mScaleRotation.ToString() +
                                "  Location: " + mLocation.ToString() +
                                "  Scale: " + mScale.ToString() +
                                "  IncludeInBoundsCalcFlag: " + mIncludeInBoundsCalcFlag.ToString() +
                                "  Transformation: " + mTransformation.ToString() +
                                "  ImportanceFactor: " + mImportanceFactor.ToString();

            return vTheString;
        }

    }


}