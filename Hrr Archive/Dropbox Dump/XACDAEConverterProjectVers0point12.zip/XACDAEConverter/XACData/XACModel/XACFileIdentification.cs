﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using XACDAEConverterCommon;

namespace XACNamespace
{

  public class XACFileIdentification
  {

    public Byte[] mXACFileID; //4 Byte
    public Byte   mMajorVersion;
    public Byte   mMinorVersion;
    public Byte   mBigEndianFlag;
    public Byte   mMultiplayOrder;


    public XACFileIdentification()
    {
      mXACFileID = new Byte[4] { 58, 41, 43, 20 }; // "XAC "
      mMajorVersion = 1;
      mMinorVersion = 0;
      mBigEndianFlag = 0;
      mMultiplayOrder = 1;
    }


    public void ReadIn(BinaryReader iStream)
    {
      mXACFileID = new Byte[4];

      mXACFileID[0] = iStream.ReadByte();
      mXACFileID[1] = iStream.ReadByte();
      mXACFileID[2] = iStream.ReadByte();
      mXACFileID[3] = iStream.ReadByte(); 

      mMajorVersion   = iStream.ReadByte();
      mMinorVersion   = iStream.ReadByte();
      mBigEndianFlag  = iStream.ReadByte();
      mMultiplayOrder = iStream.ReadByte();
    }


    public void WriteOut(BinaryWriter iStream)
    {
      if (null != mXACFileID)
      {
        for (int vIndex = 0; vIndex < mXACFileID.Length; vIndex++) //although should always be 4
        {
          iStream.Write(mXACFileID[vIndex]);
        }
      }
      iStream.Write(mMajorVersion);
      iStream.Write(mMinorVersion);
      iStream.Write(mBigEndianFlag);
      iStream.Write(mMultiplayOrder);
    }

    public long GetSize()
    {
        //That should sum up to 8  Bytes...usually
        long vSize = 0;
        if (null != mXACFileID)
        {
            vSize += (long)(mXACFileID.Length) * (long)sizeof(Byte);
        }
        vSize += 4L * (long)sizeof(Byte);
        return vSize;
    }

    public override string ToString()
    {
      string vFileID = string.Empty;
      if ((null != mXACFileID) && (4 <= mXACFileID.Length))
      {
        vFileID += mXACFileID[0].ToString() + mXACFileID[1].ToString() + mXACFileID[2].ToString() + mXACFileID[3].ToString();
      }

      string vTheString = "FileID: " + vFileID + " MajorVersion:" + mMajorVersion.ToString() + " MinorVersion:" + mMinorVersion.ToString() + " BigEndianFlag:" + mBigEndianFlag.ToString() + " MultiplayOrder:" + mMultiplayOrder.ToString();
      return vTheString;
    }

  }

}
