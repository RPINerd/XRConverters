﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using XACNamespace;
using XACDAEConverterCommon;

namespace XACNamespace
{

  public class XACParser
  {

    XACData            mXACData;
    TextBox            mStatusTextBox;
    ListBox            mListBox;
    BinaryReader       mStream;

    public XACParser(BinaryReader iStream, XACData xXACData, TextBox iStatusTextBox, ListBox iListBox1)
    {
      mXACData = xXACData;
      mStatusTextBox = iStatusTextBox;
      mStream = iStream;
      mListBox = iListBox1;
    }

    public bool Parse()
    {
      bool vError = false;

      mListBox.Items.Clear();
      mStatusTextBox.Text = string.Empty;

      long vTargetStreamPosition = 0;


      XACFileIdentification vXACFileIdentification = new XACFileIdentification();
      vXACFileIdentification.ReadIn(mStream);
      
      //The FileID should be 4 Bytes: "XAC " {58, 41, 43, 20}
      Byte[] vFiledID = vXACFileIdentification.mXACFileID;

      if ((null == vFiledID) || (4 != vFiledID.Length))
      {
        Console.WriteLine("Something is messed with the FileID read in. It's NOT 4 Bytes. Check SW Code.");
        mStatusTextBox.Text = "Something is messed with the FileID read in. It's NOT 4 Bytes. Check SW Code.";
        vError = true;
        return !vError;
      }

      //Is xac file?=
      if  (((vFiledID[0] != Convert.ToByte('X') && vFiledID[0] != Convert.ToByte('x')))
        || ((vFiledID[1] != Convert.ToByte('A') && vFiledID[1] != Convert.ToByte('a')))
        || ((vFiledID[2] != Convert.ToByte('C') && vFiledID[2] != Convert.ToByte('c')))
        || ((vFiledID[3] != Convert.ToByte(' '))))
      {
        Console.WriteLine("No XAC id in file found");
        mStatusTextBox.Text = "No XAC id in file found";
        vError = true;
        return !vError;
      }

      //If the FileID is ok we assign the FileIdentification to our XACData
      mXACData.mXACFileIdentification = vXACFileIdentification;

      //And update the TargetStreamPosition for parsing correctness checks.
      vTargetStreamPosition += vXACFileIdentification.GetSize();

      //Parse through the Chunks
      while ((mStream.BaseStream.Position < mStream.BaseStream.Length) && (!vError))
      {
         ParseChunk(ref vError, ref vTargetStreamPosition);
      }

      mListBox.SetSelected(mListBox.Items.Count - 1,false);

      if (!vError)
      {
          Trace("Finish. XAC Imported");
          mStatusTextBox.Text = "Finish. XAC Imported";
      }
      else
      {
          Trace("Error. XAC Data Extraction failed.");
          mStatusTextBox.Text = "Error. XAC Data Extraction failed.";
          mXACData.clear();
      }

      return !vError;
    }


    private void ParseChunk(ref bool xError, ref long xTargetStreamPosition)
    {
        long vAdditionalBytesRead = 0;

        UInt32 vChunkId      = mStream.ReadUInt32();
        UInt32 vChunkSize    = mStream.ReadUInt32();
        UInt32 vChunkVersion = mStream.ReadUInt32();

        xTargetStreamPosition += 12;

        UInt32 vChunkSizeToAddToTargetStreamPositionAfterChunkProcessed = vChunkSize;

        switch (vChunkId)
        {
          case 0:
            {
              //Bone
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " Bone " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              XACBone vBone = new XACBone();
              vBone.ReadIn(mStream);
              mXACData.mXACModelData.mBonesList.Add(vBone);
              break;
            }  
          case 1:
            {
              //Mesh
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " Mesh " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              XACMesh vMesh = ParseMesh();
              mXACData.mXACModelData.mMeshesList.Add(vMesh);
              break;
            }
          case 2:
            {
              //Unknown Of Chunk ID2
              //Maybe Deformation info
              //it seems to have a struct in the struct and that case the entry count doesnt add up anymore. it somehow shows more count than it has entries.
              //the indication is Value2: 7 (normal its 1)..it somewhat hints to 7 sub chunks.
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " Unknown " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              bool vTryParsing = false;
              if (vTryParsing)
              {
                XACUnknownOfChunkID2 vXACUnknownOfChunkID2 = ParseUnknownChunkID2();
                mXACData.mXACModelData.mUnknownOfChunkID2List.Add(vXACUnknownOfChunkID2);
              }
              else
              {
                SkipBytesInFile(vChunkSize);
              }
              break;
            }  
          case 3:
            {
              //MaterialA
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " MaterialA " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              XACMaterial vMaterial = ParseMaterialChunkID3(out vAdditionalBytesRead);
              mXACData.mXACModelData.mMaterialListChunkID3.Add(vMaterial);
              break;
            }
          case 4:
            {
              //Texture
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " Texture " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              XACTexture vTexture = ParseTexture();
              mXACData.mXACModelData.mTextureList.Add(vTexture);
              break;
            }
          case 5:
            {
              //MaterialB
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " MaterialB " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              XACMaterial vMaterial = ParseMaterialChunkID5();
              mXACData.mXACModelData.mMaterialListChunkID5.Add(vMaterial);
              break;
            }
          case 7:
            {
              //MetaData
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " MetaData " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              mXACData.mXACModelData.mMetaData = new XACMetaData();
              mXACData.mXACModelData.mMetaData.ReadIn(mStream);
              break;
            }
          case 11:
            {
              //NodeTree ID11 (B)
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " NodeTree " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              mXACData.mXACModelData.mNodeTree = new XACNodeTree();
              mXACData.mXACModelData.mNodeTree.ReadIn(mStream);
              break;
            }
          case 12:
            {
              //Unknown ID12 (C)
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " Unknown " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              if (vChunkSize < 10000000)
              {
                Byte[] vBuffer = new Byte[vChunkSize];
                mStream.Read(vBuffer, 0, (int)vChunkSize);
              }
              else
              {
                SkipBytesInFile(vChunkSize);
              }
              break;
            } 
          case 13:
            {
              //MaterialTotals (D)
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " MaterialTotals " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              mXACData.mXACModelData.mMaterialTotals = new XACMaterialTotals();
              mXACData.mXACModelData.mMaterialTotals.ReadIn(mStream);
              break;
            }
          default:
            {
              string vChunkInfo = "Chunk Id:" + vChunkId.ToString() + " Unknown " + " Size:" + vChunkSize.ToString() + " Version:" + vChunkVersion.ToString();
              Trace(vChunkInfo);
              SkipBytesInFile(vChunkSize);
              if (vChunkId>255)
              {
                Trace("ChunkId > 255. Unrecoverable Error. Process stopped.");
                xError = true;
              }
              break;
            }
        }

        xTargetStreamPosition += (long)vChunkSizeToAddToTargetStreamPositionAfterChunkProcessed;
        
        if (mStream.BaseStream.Position != xTargetStreamPosition)
        {
           //obviously Material ChunkID3 breaking the Chunk size rule is normal
           //Trace(iChunkTreePrefix + " Chunck size is incorrect! Attempt Autocorrection.");
           xTargetStreamPosition += vAdditionalBytesRead; //Some chunks like the Id3 Chunck seems to violate the read chunk size and requires correction
        }

        if (mStream.BaseStream.Position != xTargetStreamPosition)
        {
           Trace("Stream position incorrect! Attempt Autocorrection. " + "Expected: " + xTargetStreamPosition.ToString() + "  but is: " + mStream.BaseStream.Position.ToString() + "  and File Size Is: " + mStream.BaseStream.Length.ToString());
            //vError = true;
            xTargetStreamPosition = mStream.BaseStream.Position;
        }
    }


    private void Trace(string iString)
    {
      Console.WriteLine(iString);
      mListBox.Items.Add(iString);
      mListBox.SetSelected(mListBox.Items.Count - 1, true);
    }



    private void SkipBytesInFile(UInt32 iNrOfBytes)
    {
      Int64 vBytesToRead = (Int64)(iNrOfBytes);

      int vBufferSize = 256*256;
      Byte[] vBuffer = new Byte[vBufferSize];

      while (0 < vBytesToRead)
      {
        Int64 vLeftBytesToReadAfterABlockRead = vBytesToRead - (Int64)(vBufferSize);
        if (0 > vLeftBytesToReadAfterABlockRead)
        {
          mStream.Read(vBuffer, 0, (Int32)vBytesToRead);
        }
        else
        {
          mStream.Read(vBuffer, 0, vBufferSize);
        }
        vBytesToRead = vLeftBytesToReadAfterABlockRead;
      }
    }


    private XACUnknownOfChunkID2 ParseUnknownChunkID2()
    {
      UInt32 vValue1 = mStream.ReadUInt32();
      UInt32 vValue2 = mStream.ReadUInt32();
      UInt32 vCount  = mStream.ReadUInt32();
      mStream.ReadUInt32(); //00 47 00 00

      List<XACUnknownOfChunkID2Entry> vUnknownOfChunkID2List = new List<XACUnknownOfChunkID2Entry>();
      for (int vEntryNr = 1; vEntryNr <= vCount; vEntryNr++)
      {
        float  vValue1Entry = mStream.ReadSingle();
        UInt32 vValue2Entry = mStream.ReadUInt32();
        float  vValue3Entry = mStream.ReadSingle();
        UInt32 vValue4Entry = mStream.ReadUInt32();

        XACUnknownOfChunkID2Entry vXACUnknownOfChunkID2Entry = new XACUnknownOfChunkID2Entry(vValue1Entry, vValue2Entry, vValue3Entry, vValue4Entry);
        vUnknownOfChunkID2List.Add(vXACUnknownOfChunkID2Entry);
      }

      XACUnknownOfChunkID2 vXACUnknownOfChunkID2 = new XACUnknownOfChunkID2(vValue1, vValue2, vUnknownOfChunkID2List);
      return vXACUnknownOfChunkID2;
    }

    private XACMaterial ParseMaterialChunkID3(out long oAdditionalBytesRead)
    {
        oAdditionalBytesRead = 0;

        for (int vi = 1; vi<=16; vi++)
        {
          mStream.ReadSingle();
        }
        float vPower = mStream.ReadSingle();
        mStream.ReadSingle();
        mStream.ReadSingle();
        mStream.ReadSingle();
        mStream.ReadByte();
        mStream.ReadByte();
        mStream.ReadByte();
        int vTextureCount = (int)mStream.ReadByte();
        string vMatName = Common.ReadString(mStream);

        List<XACMatTextureEntry> vMatTextureEntryList = new List<XACMatTextureEntry>();
        for (int vTextureNr = 1; vTextureNr<=vTextureCount; vTextureNr++)
        {
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadUInt16();
            mStream.ReadUInt16();
            string vTextureName = Common.ReadString(mStream);

            oAdditionalBytesRead += (long)(6*4 + 2 *2 + 4 + vTextureName.Count()); //6floats + 2*int16 + 4 byte string header + string size

            XACMatTextureEntry vMatTextureEntry = new XACMatTextureEntry(vTextureName, null); 
            vMatTextureEntryList.Add(vMatTextureEntry);
        }
        XACMaterial vMaterial = new XACMaterial(vMatName, vMatTextureEntryList);
        return vMaterial;
    }

    private XACTexture ParseTexture()
    {
      mStream.ReadSingle();
      mStream.ReadSingle();
      mStream.ReadSingle();
      mStream.ReadSingle();
      mStream.ReadSingle();
      mStream.ReadSingle();

      UInt16 vMatNumber = mStream.ReadUInt16();
      mStream.ReadUInt16();
      string vTextureName = Common.ReadString(mStream);

      //"_d" or "_D" in vTextureName -> diffuse texture
      //"_n" or "_N" in vTextureName -> normal texture
      //none of above -> diffuse texture

      XACTexture vTexture = new XACTexture(vTextureName);
      return vTexture;
    }

    private XACMaterial ParseMaterialChunkID5()
    {
      //yulgang 2 mat chunk (untested)
      UInt32 vFxCount = mStream.ReadUInt32();
      UInt32 vCount1  = mStream.ReadUInt32();
      UInt32 vCount2  = mStream.ReadUInt32();
      UInt32 vCount3  = mStream.ReadUInt32();
      mStream.ReadUInt32();
      UInt32 vTexMapsCount = mStream.ReadUInt32();
      string vMatName = Common.ReadString(mStream);
        
      List<XACMatTextureEntry> vMatTextureEntryList = new List<XACMatTextureEntry>();
      for (UInt32 vi = 1; vi<= vFxCount; vi++)
      {
            Common.ReadString(mStream);
            Common.ReadString(mStream);
            mStream.ReadUInt32();
      }
      for (UInt32 vi = 1; vi<= vCount1; vi++)
      {      
            Common.ReadString(mStream);
            mStream.ReadSingle();
      }
       for (UInt32 vi = 1; vi<= vCount2; vi++)
      {   
            Common.ReadString(mStream);
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadSingle();
            mStream.ReadSingle();
      }
      for (UInt32 vi = 1; vi<= vCount3; vi++)
      {     
            Common.ReadString(mStream);
            mStream.ReadByte();
      }
        
      mStream.ReadSingle();
             
      for (UInt32 vi = 1; vi<= vTexMapsCount; vi++)
      {    
            string vTextureType     = Common.ReadString(mStream);
            string vTextureName     = Common.ReadString(mStream);
            
            //vTextureType can be:
            // "DIFFUSECOLOR" or  "diffuseTexture"
            // "BUMP" or  "normalTexture"
            // "specTexture"
            // "MASK" or  "maskTexture"
            // "glowTexture"
            XACMatTextureEntry vMatTextureEntry = new XACMatTextureEntry(vTextureName, vTextureType); 
            vMatTextureEntryList.Add(vMatTextureEntry);
      }

      XACMaterial vMaterial = new XACMaterial(vMatName, vMatTextureEntryList);
      return vMaterial;
    }



    private XACMesh ParseMesh()
    {

      XACMesh vMesh = new XACMesh();

      mStream.ReadUInt32();
      mStream.ReadUInt32();

      UInt32 vVerticesCount = mStream.ReadUInt32();

      mStream.ReadUInt32();

      UInt32 vFaceGroupsCount = mStream.ReadUInt32();
      UInt32 vStructsCount    = mStream.ReadUInt32();

      mStream.ReadUInt32();
      mStream.ReadUInt32();
      mStream.ReadUInt32();
      mStream.ReadUInt32();

      //Vertices id's?
      for (int vCount = 1; vCount <= vVerticesCount; vCount++)
      {
        mStream.ReadUInt32(); //read UInt32s
      }

      for (int vStructNr = 1; vStructNr <= (vStructsCount - 1); vStructNr++)
      {
        UInt32 vStructId = mStream.ReadUInt32();
        UInt32 vStructSize = mStream.ReadUInt32(); //Bytes per entry
        UInt32 vUnknown = mStream.ReadUInt32(); //Unknown

        switch (vStructId)
        {
          case 0:
            {
              List<XACVertice> vVerticesList = ParseVertices(vVerticesCount);
              vMesh.mVerticesList = new List<XACVertice>(vVerticesList);
              break;
            }
          case 1:
            {
              List<XACNormal> vNormalsList = ParseNormals(vVerticesCount);
              vMesh.mNormalsList = new List<XACNormal>(vNormalsList);
              break;
            }
          case 2:
            {
              List<XACWeight> vWeightsList = ParseWeights(vVerticesCount);
              vMesh.mWeightsList = new List<XACWeight>(vWeightsList);
              break;
            }
          case 3:
            {
              List<XACUVCoord> vUVCoordList = ParseUVCoords(vVerticesCount);
              vMesh.mUVCoordsList = new List<XACUVCoord>(vUVCoordList);
              break;
            }
          case 4:
            {
               List<XACVerticeColor> vVerticeColorList = ParseVerticeColors(vVerticesCount);
               vMesh.mVerticeColorList = new List<XACVerticeColor>(vVerticeColorList);
               break;
            }
          default:
            {
              Trace("Unknown Mesh Struct ID: " + vStructId.ToString());
              SkipBytesInFile(vStructSize*vVerticesCount);
              break;
            }
        }
      }

      //Hm the Last Group is always that FaceGroupList???
      List<XACFaceGroup> vFaceGroupList = ParseFaceGroups(vFaceGroupsCount);
      vMesh.mFaceGroupList = new List<XACFaceGroup>(vFaceGroupList);

      return vMesh;     
    }


    private List<XACUVCoord> ParseUVCoords(UInt32 iVerticesCount)
    {
      List<XACUVCoord> vUVCoordsList = new List<XACUVCoord>();

      for (UInt32 vVerticesNr = 1; vVerticesNr <= iVerticesCount; vVerticesNr++)
      {
        float vU = mStream.ReadSingle();
        float vV = mStream.ReadSingle();
        XACUVCoord vUVCoord = new XACUVCoord(vU, vV);
        vUVCoordsList.Add(vUVCoord);
      }
      return vUVCoordsList;
    }

    private List<XACWeight> ParseWeights(UInt32 iVerticesCount)
    {
      List<XACWeight> vWeightList = new List<XACWeight>();

      for (UInt32 vVerticesNr = 1; vVerticesNr <= iVerticesCount; vVerticesNr++)
      {
        float vWeight1 = mStream.ReadSingle();
        float vWeight2 = mStream.ReadSingle();
        float vWeight3 = mStream.ReadSingle();
        float vWeight4 = mStream.ReadSingle();
        XACWeight vWeight = new XACWeight(vWeight1, vWeight2, vWeight3, vWeight4);
        vWeightList.Add(vWeight);
      }
      return vWeightList;
    }

    private List<XACVerticeColor> ParseVerticeColors(UInt32 iVerticesCount)
    {
        List<XACVerticeColor> vVerticeColorsList = new List<XACVerticeColor>();

        for (UInt32 vVerticesNr = 1; vVerticesNr <= iVerticesCount; vVerticesNr++)
        {
            Byte vA = mStream.ReadByte();
            Byte vB = mStream.ReadByte();
            Byte vC = mStream.ReadByte();
            Byte vD = mStream.ReadByte();
            XACVerticeColor vVerticeColor = new XACVerticeColor(vA, vB, vC, vD);
            vVerticeColorsList.Add(vVerticeColor);
        }
        return vVerticeColorsList;
    }

    private List<XACNormal> ParseNormals(UInt32 iVerticesCount)
    {
      List<XACNormal> vNormalsList = new List<XACNormal>();

      for (UInt32 vVerticesNr = 1; vVerticesNr <= iVerticesCount; vVerticesNr++)
      {
        float vX = mStream.ReadSingle();
        float vY = mStream.ReadSingle();
        float vZ = mStream.ReadSingle();
        XACNormal vNormal = new XACNormal(vX, vY, vZ);
        vNormalsList.Add(vNormal);
      }
      return vNormalsList;
    }

    private List<XACVertice> ParseVertices(UInt32 iVerticesCount)
    {
      List<XACVertice> vVerticesList = new List<XACVertice>();

      for (UInt32 vVerticesNr = 1; vVerticesNr <= iVerticesCount; vVerticesNr++)
      {
        float vX = mStream.ReadSingle();
        float vY = mStream.ReadSingle();
        float vZ = mStream.ReadSingle();
        XACVertice vVertices = new XACVertice(vX, vY, vZ);
        vVerticesList.Add(vVertices);
      }
      return vVerticesList;
    }


    private List<XACFaceGroup> ParseFaceGroups(UInt32 iFaceGroupsCount)
    {
      List<XACFaceGroup> vFaceGroupList = new List<XACFaceGroup>();
      for (UInt32 vFaceGroupNr = 1; vFaceGroupNr <= iFaceGroupsCount; vFaceGroupNr++)
      {
        UInt32 vVerticesIndexesCount = mStream.ReadUInt32();
        UInt32 vFaceGroupVerticesCount = mStream.ReadUInt32();
        UInt32 vMaterialCount = mStream.ReadUInt32();
        UInt32 vBonesCount = mStream.ReadUInt32();

        if ((vVerticesIndexesCount % 3) != 0)
        {
          //Error it should be modulo 3 because triangles always have 3 points
          Trace("XAC ERROR: The read VerticesIndexesCount " + vVerticesIndexesCount.ToString()  + " is not modulo 3!");
        }

        UInt32 vFacesCount = vVerticesIndexesCount / 3;

        List<XACFace> vFacesList = new List<XACFace>();
        for (UInt32 vFaceNr = 1; vFaceNr <= vFacesCount; vFaceNr++)
        {
          XACFace vFace = ParseTriangleFace();
          vFacesList.Add(vFace);
        }

        for (UInt32 i = 1; i <= vBonesCount; i++)
        {
          mStream.ReadUInt32();
        }

        XACFaceGroup vFaceGroup = new XACFaceGroup(vFacesList, vFaceGroupVerticesCount, vBonesCount);
        vFaceGroupList.Add(vFaceGroup);

      }
      return vFaceGroupList;
    }

    private XACFace ParseTriangleFace()
    {
      List<UInt32> vVerticesIndexsList = new List<UInt32>();
      vVerticesIndexsList.Add(mStream.ReadUInt32());
      vVerticesIndexsList.Add(mStream.ReadUInt32());
      vVerticesIndexsList.Add(mStream.ReadUInt32());
      XACFace vFace = new XACFace(vVerticesIndexsList);
      return vFace;
    }

  }
}
