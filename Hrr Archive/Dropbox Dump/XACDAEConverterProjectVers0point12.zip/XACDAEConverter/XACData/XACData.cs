﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XACNamespace
{

  public class XACData
  {
      public XACFileIdentification mXACFileIdentification;
      public XACModelData mXACModelData;

      public XACData()
      {
          mXACFileIdentification = new XACFileIdentification();
          mXACModelData = new XACModelData();
      }

      public void clear()
      {
          mXACFileIdentification = new XACFileIdentification();
          mXACModelData = new XACModelData();
      }
  }
  
}
