﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace XACDAEConverterCommon
{
  public static class Common
  {

    //The XAC uses 4Byte for the letter count there fore we can't use the standard ReadString method 
    public static string ReadString(BinaryReader iStream)
    {
      string vTheString = string.Empty;
      uint vChars = iStream.ReadUInt32();
      if (vChars > 0)
      {
        char[] vCharArray = iStream.ReadChars((int)vChars);
        vTheString = new string(vCharArray, 0, (int)vChars);
      }
      return vTheString;
    }


    //Write the string..note that an empty string becomes 4 zero bytes
    public static void WriteString(BinaryWriter iStream, string iString)
    {
      string vTheString = string.Empty;
      if (!string.IsNullOrEmpty(iString))
      {
        vTheString = iString;
      }
      UInt32 vStringLength = (UInt32)vTheString.Length;
      iStream.Write(vStringLength);
      char [] vChars = vTheString.ToCharArray();
      iStream.Write(vChars, 0, vTheString.Length);
    }


    //for debugging
    public static void Read256Bytes(BinaryReader iStream)
    {
      Byte[] vBuffer = new Byte[256];
      iStream.Read(vBuffer, 0, 256);
    }

  }

}